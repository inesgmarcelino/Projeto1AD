Aplicações distribuídas - Projeto 3 - README.txt
Grupo: 25
Números de aluno: Sofia Lourenço 54950, Inês Marcelino 54991

Após a realização deste projeto 3, apenas concluímos que as únicas limitações
encontradas foi no tratamento de erros (try/except), fizemos 3 exceções no client.py
mas de resto não sabemos que mais erros são possíveis de acontecer.
Todos os comandos funcionam, sendo que no comando CREATE não é permitido criar um
artista/álbum do qual o seu id_spotify já se encontre na base de dados.

O programa deve correr como pedido no enunciado do projeto.

Dados inseridos em RateAlbums.db:

utilizadores:
(id)1 | user1 | user1 
(id)2 | user2 | user2

artistas:
(id)1 | 4LLpKhyESsyAXpc4laK94U | Mac Miller
(id)2 | 3mIj9lX2MWuHmhNCA7LSCW | The 1975
(id)3 | 6l3HvQ5sa6mXTsMTB19rO5 | J. Cole

albuns:
(id)1 | 5sY6UIQ32GqwMLAfSNEaXb | Circles | 1
(id)2 | 6f6tko6NWoH00cyFOl4VYQ | The Divine Feminine | 1
(id)3 | 5wtE5aLX5r7jOosmPhJhhk | Swimming | 1
(id)4 | 6PWXKiakqhI17mTYM4y6oY | A Brief Inquiry Into Online Relationships | 2
(id)5 | 6Z1zv6Hw9bdvSoxI5uYk2h | The 1975 | 2
(id)6 | 12zl1WmHPFCSyKYbL4vBZn | I like it when you sleep, for you are so beautiful yet so unaware of it | 2
(id)7 | 7viNUmZZ8ztn2UB4XB3jIL | 2014 Forest Hills Drive | 3
(id)8 | 3CCnGldVQ90c26aFATC1PW | 4 Your Eyez Only | 3

listas_albuns:
(user)1 | (album)4 | (aval)4
(user)1 | (album)7 | (aval)3
(user)2 | (album)5 | (aval)5
(user)2 | (album)1 | (aval)1
(user)1 | (album)1 | (aval)2

