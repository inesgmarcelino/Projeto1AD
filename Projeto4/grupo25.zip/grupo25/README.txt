Aplicações distribuídas - Projeto 4 - README.txt
Grupo: 25
Números de aluno: Sofia Lourenço 54950, Inês Marcelino 54991

Após a realização deste projeto 4, as limitações encontradas no projeto 3 relativas à possível falta
de try/excepts no programa mantêm-se, apesar de não afetar em nada o seu bom funcionamento.
De resto, todos os comandos funcionam, sendo que no comando CREATE não é permitido criar um
artista/álbum do qual o seu id_spotify já se encontre na base de dados.
O programa deve correr como pedido no enunciado do projeto.

Em relação ao projeto entregue anteriormente, reparamos que não metemos o cabeçalho de identificação no
ficheiro .sql, foi corrigido neste projeto.

Dados inseridos em RateAlbums.db:

utilizadores:
(id)1 | user1 | user1 
(id)2 | user2 | user2

artistas:
(id)1 | 4LLpKhyESsyAXpc4laK94U | Mac Miller
(id)2 | 3mIj9lX2MWuHmhNCA7LSCW | The 1975
(id)3 | 6l3HvQ5sa6mXTsMTB19rO5 | J. Cole
(id)4 | 0C8ZW7ezQVs4URX5aX7Kqx | Selena Gomez

albuns:
(id)1 | 5sY6UIQ32GqwMLAfSNEaXb | Circles | 1
(id)2 | 6f6tko6NWoH00cyFOl4VYQ | The Divine Feminine | 1
(id)3 | 5wtE5aLX5r7jOosmPhJhhk | Swimming | 1
(id)4 | 6PWXKiakqhI17mTYM4y6oY | A Brief Inquiry Into Online Relationships | 2
(id)5 | 6Z1zv6Hw9bdvSoxI5uYk2h | The 1975 | 2
(id)6 | 12zl1WmHPFCSyKYbL4vBZn | I like it when you sleep, for you are so beautiful yet so unaware of it | 2
(id)7 | 7viNUmZZ8ztn2UB4XB3jIL | 2014 Forest Hills Drive | 3
(id)8 | 3CCnGldVQ90c26aFATC1PW | 4 Your Eyez Only | 3

listas_albuns:
(user)1 | (album)4 | (aval)4
(user)1 | (album)7 | (aval)3
(user)2 | (album)5 | (aval)5
(user)2 | (album)1 | (aval)1
(user)1 | (album)1 | (aval)2

