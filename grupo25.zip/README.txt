Aplicações distribuídas - Projeto 1 - README.txt
Grupo: 25
Números de aluno: Sofia Lourenço 54950, Inês Marcelino 54991

Tivemos dificuldades na função receive_all() porque durante uma explicação
do professor, foi mencionado que deveria haver um loop para que seja verificado
se é recebido um determinado tamanho de mensagem, como não percebemos muito bem
essa parte, fizemos a função exatamente igual á da primeira PL.

De resto, o programa deve correr como pedido no enunciado do projeto.
